document.getElementById("toggleButton").addEventListener("click", function() {
    const nav = document.getElementById("nav");
    if (nav.style.display === "none" || nav.style.display === "") {
        nav.style.display = "block"; // Show the nav
    } else {
        nav.style.display = "none"; // Hide the nav
    }
});
